﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace CRM_System
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private ObservableCollection<Orders> orders;

        public MainWindow()
        {
            InitializeComponent();

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            orders = MyStorage1.ReadXML<ObservableCollection<Orders>>("orders.xml");
            DateTime mdate = DateTime.Now;
            Order_Date.Text = mdate.ToString("dd/MM/yyyy");
            Order_Time.Text = mdate.ToString("HH:mm:ss");

            //orders = MyStorage1.ReadXML<ObservableCollection<Orders>>("orders.xml");
            LBx_orders.ItemsSource = orders;
            DataGrid_Orders.ItemsSource = orders;

            
            
        }

        private ObservableCollection<Orders> GenerateData()
        {
            var o1 = new Orders { CustomerID = "C1", CustomerName = "Luisa Schulz", CustomerAddress = "L13, 6, Mannheim", CustomerContact = "017623684445", OrderID = "ORD001", OrderStatus = "In Progress", OrderDate = "05/05/2018", OrderTime = "04:05:55", Item = "Mixer", Quantity = "1", UnitPrice = "10", SubTotal = "10" };

            var o2 = new Orders { CustomerID = "C2", CustomerName = "Marie Schulz", CustomerContact = "017623684578", CustomerAddress = "L13,9,Mannheim", OrderID = "ORD002", OrderStatus = "Pending", OrderDate = "05/08/2018", OrderTime = "04:08:55", Item = "Mixer", ProductID = "P10", Quantity = "10", UnitPrice = "10", SubTotal = "100" };

            var o3 = new Orders { CustomerID = "C3", CustomerName = "Noah Morsch", CustomerContact = "017623684555", CustomerAddress = "L13,10,Mannheim", OrderID = "ORD003", OrderStatus = "Delivered", OrderDate = "05/05/2018", OrderTime = "04:05:55", Item = "Mixer", Quantity = "10", UnitPrice = "10", SubTotal = "100" };

            var o4 = new Orders { CustomerID = "C4", CustomerName = "Minu Rawal", CustomerContact = "017623684556", CustomerAddress = "L13, 55 ,Mannheim", OrderID = "ORD004", OrderStatus = "Delivered", OrderDate = "05/05/2018", OrderTime = "04:05:55", Item = "Mixer", Quantity = "10", UnitPrice = "10", SubTotal = "100" };

            var o5 = new Orders { CustomerID = "C5", CustomerName = "Insa Borm", CustomerContact = "017623688888", CustomerAddress = "L12,8,Mannheim" , OrderID = "ORD005", OrderStatus = "Delivered", OrderDate = "05/05/2018", OrderTime = "04:05:55", Item = "Mixer", Quantity = "10", UnitPrice = "10", SubTotal = "100" };

            var o6 = new Orders { CustomerID = "C6", CustomerName = "Alisa Walsch", CustomerAddress = "L18,8,Mannheim", OrderID = "ORD006", OrderStatus = "Delivered", OrderDate = "05/05/2018", OrderTime = "04:05:55", Item = "Mixer", Quantity = "10", UnitPrice = "10", SubTotal = "100" };

            var o7 = new Orders { CustomerID = "C7", CustomerName = "Luisa Bright", CustomerContact = "017623689999", CustomerAddress = "L1,8,Mannheim", OrderID = "ORD007", OrderStatus = "Delivered", OrderDate = "05/05/2018", OrderTime = "04:05:55", Item = "Mixer", Quantity = "10", UnitPrice = "10", SubTotal = "100" };

            var o8 = new Orders { CustomerID = "C8", CustomerName = "Martin Schulz", CustomerContact = "017623687777", CustomerAddress = "L13,6,Mannheim", OrderID = "ORD008", OrderStatus = "Delivered", OrderDate = "05/05/2018", OrderTime = "04:05:55", Item = "Mixer", Quantity = "10", UnitPrice = "10", SubTotal = "100" };

            var o9 = new Orders { CustomerID = "C9", CustomerName = "Jenny Bright", CustomerContact = "017623111111", CustomerAddress = "L15,8,Mannheim", OrderID = "ORD009", OrderStatus = "Delivered", OrderDate = "05/05/2018", OrderTime = "04:05:55", Item = "Mixer", Quantity = "10", UnitPrice = "10", SubTotal = "100" };

            var o10 = new Orders { CustomerID = "C10", CustomerName = "Vijay Rawal", CustomerContact = "01762368879", CustomerAddress = "L13,14,Mannheim", OrderID = "ORD010", OrderStatus = "Delivered", OrderDate = "05/05/2018", OrderTime = "04:05:55", Item = "Mixer", Quantity = "10", UnitPrice = "10", SubTotal = "100" };

            var or = new ObservableCollection<Orders> { o1, o2, o3, o4, o5, o6, o7, o8, o9 };
            return or;
        }



        private void Manage_Vendor(object sender, RoutedEventArgs e)
        {
            Management_Window win3 = new Management_Window
            {
                Owner = this
            };
            win3.Show();
        }

        
      

        private void Create_Order(object sender, RoutedEventArgs e)
        {
            DateTime mdate = DateTime.Now;
            Order_Date.Text = mdate.ToString("dd/MM/yyyy");
            Order_Time.Text = mdate.ToString("HH:mm:ss");

            var or = new Orders();
            or.CustomerName = CustomerName.Text;
            or.CustomerID = CustomerID.Text;
            or.CustomerContact = CustomerContact.Text;
            or.CustomerAddress = CustomerAddress.Text;
            or.OrderID = OrderID.Text;
            or.OrderStatus = cBox.Text;
            or.OrderDate = Order_Date.Text;
            or.OrderTime = Order_Time.Text;
            or.Item = Item1.Text;
            or.ProductID = ProductID.Text;
            or.Quantity = Quantity.Text;
            or.SubTotal = SubTotal.Text;
            or.GrandTotal = GrandTotal.Text;
            orders.Add(or);
            DataGrid_Orders.SelectedItem = or;
            DataGrid_Orders.ItemsSource = orders;

        }

        private void TBx_filter_TextChanged(object sender, TextChangedEventArgs e)
        {
           
           var lst = from or in orders where or.CustomerName.ToLower().Contains(TBx_filter.Text.ToLower()) select or;
           DataGrid_Orders.ItemsSource = lst;
           LBx_orders.ItemsSource = lst;
           
        }

        private void Delete_Order(object sender, RoutedEventArgs e)
        {
           

            if (LBx_orders.SelectedItem == null)
            {
                MessageBox.Show("Please select an item to be deleted..");
                return;
            }

            orders.Remove(LBx_orders.SelectedItem as Orders);

            LBx_orders.ItemsSource = orders;
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            MyStorage1.WriteXML<ObservableCollection<Orders>>("orders.xml", orders);
        }

      
    }
}
