﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CRM_System
{
    /// <summary>
    /// Interaction logic for Vendor_Window.xaml
    /// </summary>
    public partial class Management_Window : Window
    {
        ObservableCollection<Vendors> vendors;
        public static ObservableCollection<Customers> customers;
        public static ObservableCollection<Products> products;
        public Management_Window()
        {
            InitializeComponent();
        }

        protected ObservableCollection<Vendors> GenerateData3()
        {
            var v1 = new Vendors { VendorID = "V1", VenderName = "Nike Suppliers", VendorMobile = "017623684567", VendorEmail = "VendorSupport@nike.com", VendorAddress = "M1,8,Mannheim" };
            var v2 = new Vendors { VendorID = "V2", VenderName = "Addidas Suppliers", VendorMobile = "017623684888", VendorEmail = "VendorSupport@addidas.com", VendorAddress = "M1,9,Mannheim" };
            var v3 = new Vendors { VendorID = "V3", VenderName = "Bosch Suppliers", VendorMobile = "017623684888", VendorEmail = "VendorSupport@bosch.com", VendorAddress = "M1,15,Mannheim" };
            var v4 = new Vendors { VendorID = "V4", VenderName = "Cartier Suppliers", VendorMobile = "017623684455", VendorEmail = "VendorSupport@cartier.com", VendorAddress = "N1,8,Mannheim" };
            var v5 = new Vendors { VendorID = "V5", VenderName = "Siemens Suppliers", VendorMobile = "017623688888", VendorEmail = "VendorSupport@siemens.com", VendorAddress = "M11,8,Mannheim" };


            var vr = new ObservableCollection<Vendors> { v1, v2, v3, v4, v5 };
            return vr;

        }

        private ObservableCollection<Customers> GenerateData1()

        {

            var c1 = new Customers { CustomerID = "C1", CustomerName = "Luisa Schulz", CustomerMobile = "017623684567", CustomerEmail = "Luisa.Schulz@gmail.com", CustomerAddress = "L13,8,Mannheim" };
            var c2 = new Customers { CustomerID = "C2", CustomerName = "Marie Schulz", CustomerMobile = "017623684578", CustomerEmail = "Marie.Schulz@gmail.com", CustomerAddress = "L13,9,Mannheim" };
            var c3 = new Customers { CustomerID = "C3", CustomerName = "Noah Morsch", CustomerMobile = "017623684555", CustomerEmail = "noah.morsch@gmail.com", CustomerAddress = "L13,10,Mannheim" };
            var c4 = new Customers { CustomerID = "C4", CustomerName = "Franziska Killen", CustomerMobile = "017623684445", CustomerEmail = "Franziska.killen@gmail.com", CustomerAddress = "L13,11,Mannheim" };
            var c5 = new Customers { CustomerID = "C5", CustomerName = "Insa Borm", CustomerMobile = "017623688888", CustomerEmail = "Insa.Borm@gmail.com", CustomerAddress = "L12,8,Mannheim" };
            var c6 = new Customers { CustomerID = "C6", CustomerName = "Alisa Walsch", CustomerMobile = "017623683333", CustomerEmail = "Alisa.Walsch@gmail.com", CustomerAddress = "L18,8,Mannheim" };
            var c7 = new Customers { CustomerID = "C7", CustomerName = "Luisa Bright", CustomerMobile = "017623689999", CustomerEmail = "Luisa.Bright@gmail.com", CustomerAddress = "L1,8,Mannheim" };
            var c8 = new Customers { CustomerID = "C8", CustomerName = "Martin Schulz", CustomerMobile = "017623687777", CustomerEmail = "Martin.Schulz@gmail.com", CustomerAddress = "L13,6,Mannheim" };
            var c9 = new Customers { CustomerID = "C9", CustomerName = "Jenny Bright", CustomerMobile = "017623111111", CustomerEmail = "Jenny.Bright@gmail.com", CustomerAddress = "L15,8,Mannheim" };
            var c10 = new Customers { CustomerID = "C10", CustomerName = "Vijay Rawal", CustomerMobile = "01762368879", CustomerEmail = "Vijay.Rawal@gmail.com", CustomerAddress = "L13,14,Mannheim" };

            var cr = new ObservableCollection<Customers> { c1, c2, c3, c4, c5, c6, c7, c8, c9, c10 };
            return cr;


        }

        private ObservableCollection<Products> GenerateData2()

        {
            var p1 = new Products { ProductId = "P1", ProductType = "Sports Shoe", ProductDescription = "sport shoes of Addidas", ProductPrice = "100", ProductQty = "50" };
            var p2 = new Products { ProductId = "P2", ProductType = "Sports Shoe", ProductDescription = "sport shoes of Nike", ProductPrice = "150", ProductQty = "100" };
            var p3 = new Products { ProductId = "P3", ProductType = "Camera Strap", ProductDescription = "RS-DR1 Double camera strap", ProductPrice = "110", ProductQty = "50" };
            var p4 = new Products { ProductId = "P4", ProductType = "Rucksack", ProductDescription = "Rucksack of American Tourister", ProductPrice = "180", ProductQty = "55" };
            var p5 = new Products { ProductId = "P5", ProductType = "Coffee Maschine", ProductDescription = "Jura Capresso Pump Espresso & Cappuccino", ProductPrice = "160", ProductQty = "10" };
            var p6 = new Products { ProductId = "P6", ProductType = "Laptop", ProductDescription = "Lenovo Ideapad Yoga Ultrabook", ProductPrice = "1000", ProductQty = "10" };
            var p7 = new Products { ProductId = "P7", ProductType = "Electric Tea kettle", ProductDescription = "Chef's choice electric tea kettle", ProductPrice = "49", ProductQty = "50" };
            var p8 = new Products { ProductId = "P8", ProductType = "Electric Tea kettle", ProductDescription = "Farberware Electric Tea kettle", ProductPrice = "30", ProductQty = "50" };
            var p9 = new Products { ProductId = "P9", ProductType = "Wrist watch", ProductDescription = "Cartier watch", ProductPrice = "2000", ProductQty = "15" };
            var p10 = new Products { ProductId = "P10", ProductType = "Mixer", ProductDescription = "KitchenAid Artesian 5-qt Stand Mixer ", ProductPrice = "149", ProductQty = "20" };

            var pr = new ObservableCollection<Products> { p1, p2, p3, p4, p5, p6, p7, p8, p9, p10 };
            return pr;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            customers = MyStorage1.ReadXML<ObservableCollection<Customers>>("customers.xml");
            products = MyStorage1.ReadXML<ObservableCollection<Products>>("products.xml");
            vendors = MyStorage1.ReadXML<ObservableCollection<Vendors>>("vendors.xml");

           // vendors = GenerateData3();
            DataGrid3.ItemsSource = vendors;

          // customers = GenerateData1();
            DataGrid2.ItemsSource = customers;

           // products = GenerateData2();
            DataGrid1.ItemsSource = products;

        }


        private void Delete_vendor(object sender, RoutedEventArgs e)
        {
            if (DataGrid3.SelectedItem == null)

            {

                MessageBox.Show("Please select the vendor to be deleted");

                return;

            }

            vendors.Remove(DataGrid3.SelectedItem as Vendors);

            DataGrid3.ItemsSource = vendors;
        }

       

        private void Sort_vendor(object sender, RoutedEventArgs e)
        {
            var lst = from v in vendors orderby v.VenderName select v;
            DataGrid3.ItemsSource = lst;
        }

        

        private void Create_vendor(object sender, RoutedEventArgs e)
        {
            var vr = new Vendors();
            vendors.Add(vr);
            vr.VendorID = VendorID.Text;
            vr.VenderName = VendorName.Text;
            vr.VendorMobile = VendorMobile.Text;
            vr.VendorEmail = VendorEmail.Text;
            vr.VendorAddress = VendorAddress.Text;
            DataGrid3.SelectedItem = vr;
            DataGrid3.ItemsSource = vendors;

        }

        private void Create_customer(object sender, RoutedEventArgs e)
        {
            var cr = new Customers();
            customers.Add(cr);
            cr.CustomerID = CustomerID.Text;
            cr.CustomerName = CustomerName.Text;
            cr.CustomerMobile = CustomerMobile.Text;
            cr.CustomerEmail = CustomerEmail.Text;
            cr.CustomerAddress = cr.CustomerAddress;
            DataGrid2.SelectedItem = cr;
            DataGrid2.ItemsSource = customers;
        }

        private void Delete_customer1(object sender, RoutedEventArgs e)
        {
            if (DataGrid2.SelectedItem == null)

            {

                MessageBox.Show("Please select the customer to be deleted");

                return;

            }

            customers.Remove(DataGrid2.SelectedItem as Customers);

            DataGrid2.ItemsSource = customers;

        }

        private void Sort_customer1(object sender, RoutedEventArgs e)
        {
            var lst = from c in customers orderby c.CustomerName select c;
            DataGrid2.ItemsSource = lst;
        }

        private void Create_product(object sender, RoutedEventArgs e)
        {
            var pr = new Products();
            products.Add(pr);
            pr.ProductId = ProductID.Text;
            pr.ProductType = ProductType.Text;
            pr.ProductQty = ProductQty.Text;
            pr.ProductPrice = ProductPrice.Text;
            pr.ProductDescription = ProductDescription.Text;
           
            DataGrid1.SelectedItem = pr;
            DataGrid1.ItemsSource = products;
        }

        private void Delete_product1(object sender, RoutedEventArgs e)
        {
            if (DataGrid1.SelectedItem == null)

            {

                MessageBox.Show("Please select the product to be deleted");

                return;

            }

            products.Remove(DataGrid1.SelectedItem as Products);

            DataGrid1.ItemsSource = products;
        }

        private void Sort_product1(object sender, RoutedEventArgs e)
        {
            var lst = from p in products orderby p.ProductType select p;
            DataGrid1.ItemsSource = lst;
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            MyStorage1.WriteXML<ObservableCollection<Customers>>("customers.xml", customers);
            MyStorage1.WriteXML<ObservableCollection<Vendors>>("vendors.xml", vendors);
            MyStorage1.WriteXML<ObservableCollection<Products>>("products.xml",products);
        }
    }
}
