﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRM_System
{
  public class Orders
    {
        public string CustomerID { get; set; }
        public string CustomerName { get; set; }
        public string CustomerContact { get; set; }
        public string CustomerAddress{ get; set; }
        public string OrderID { get; set; }
        public string OrderStatus { get; set; }
        public string OrderDate { get; set; }
        public string OrderTime { get; set; }
        public string ProductID { get; set; }
        public string Item { get; set; }
        public string Quantity { get; set; }
        public string UnitPrice { get; set; }
        public string SubTotal { get; set; }
        public string GrandTotal { get; set; }

    }
}
