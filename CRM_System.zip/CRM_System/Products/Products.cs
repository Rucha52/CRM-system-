﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRM_System
{
    public class Products
    {

        public string ProductId { get; set; }
        public string ProductType { get; set; }
        public string ProductDescription { get; set; }
        public string ProductPrice { get; set; }
        public string ProductQty { get; set; }
    }
}
    